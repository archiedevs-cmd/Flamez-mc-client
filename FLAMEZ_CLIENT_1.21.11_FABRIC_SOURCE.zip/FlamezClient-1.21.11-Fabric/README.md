# FLAMEZ CLIENT — Minecraft 1.21.11 / Fabric

A client-side visual-mod starter project with a Flamez-themed settings screen.

## Included in this starter
- Right Shift opens the Flamez menu.
- Click the sky preset button to cycle Cosmic, Comet, Nebula, and Vanilla.
- Toggle controls for custom particles, particle removal, custom crosshair, hit colour, hitbox outlines, and the custom loading-screen option.
- Dark panel with orange flame-coloured accents.

## Important status
This is a **starter implementation**. The menu and settings controls are implemented, but the visual toggles are currently settings placeholders: the sky renderer, particle renderer, crosshair replacement, hit-colour effect, hitbox renderer, and loading-screen replacement still need their rendering hooks implemented and tested in-game. The project is not presented as a finished compiled mod.

## Build
Requirements: JDK 21 and Gradle.

From this folder run:

```bash
gradle build
```

The remapped mod JAR will be created in `build/libs/`.

Install the resulting JAR in the `mods` folder alongside Fabric Loader and Fabric API for Minecraft 1.21.11.

## Compatibility
- Minecraft Java Edition 1.21.11
- Fabric Loader 0.18.1
- Fabric API 0.141.1+1.21.11
- Java 21
