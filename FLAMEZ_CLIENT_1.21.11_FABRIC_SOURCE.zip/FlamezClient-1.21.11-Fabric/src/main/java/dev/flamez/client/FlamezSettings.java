package dev.flamez.client;

public final class FlamezSettings {
    private FlamezSettings() {}

    public static int skyPreset = 0;
    public static boolean customParticles = true;
    public static boolean hideParticles = false;
    public static boolean customCrosshair = false;
    public static boolean hitColour = false;
    public static boolean hitboxOutlines = false;
    public static boolean customLoadingScreen = true;

    public static final String[] SKY_PRESETS = {
            "Cosmic", "Comet", "Nebula", "Vanilla"
    };

    public static String skyName() {
        return SKY_PRESETS[Math.floorMod(skyPreset, SKY_PRESETS.length)];
    }
}
