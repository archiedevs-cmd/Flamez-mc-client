package dev.flamez.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class FlamezMenuScreen extends Screen {
    private static final int PANEL_WIDTH = 310;
    private static final int BUTTON_WIDTH = 136;

    public FlamezMenuScreen() {
        super(Component.literal("Flamez Client"));
    }

    @Override
    protected void init() {
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = Math.max(34, (this.height - 250) / 2);
        int gap = 8;
        int right = left + BUTTON_WIDTH + gap;

        addRenderableWidget(Button.builder(skyLabel(), button -> {
            FlamezSettings.skyPreset = (FlamezSettings.skyPreset + 1) % FlamezSettings.SKY_PRESETS.length;
            button.setMessage(skyLabel());
        }).bounds(left, top + 42, PANEL_WIDTH, 20).build());

        addToggle(left, right, top + 70, "Custom particles", () -> FlamezSettings.customParticles,
                value -> FlamezSettings.customParticles = value);
        addToggle(left, right, top + 98, "Remove particles", () -> FlamezSettings.hideParticles,
                value -> FlamezSettings.hideParticles = value);
        addToggle(left, right, top + 126, "Custom crosshair", () -> FlamezSettings.customCrosshair,
                value -> FlamezSettings.customCrosshair = value);
        addToggle(left, right, top + 154, "Hit colour", () -> FlamezSettings.hitColour,
                value -> FlamezSettings.hitColour = value);
        addToggle(left, right, top + 182, "Hitbox outlines", () -> FlamezSettings.hitboxOutlines,
                value -> FlamezSettings.hitboxOutlines = value);
        addToggle(left, right, top + 210, "Flamez loading screen", () -> FlamezSettings.customLoadingScreen,
                value -> FlamezSettings.customLoadingScreen = value);

        addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
                .bounds(left + 87, top + 242, 136, 20).build());
    }

    private Component skyLabel() {
        return Component.literal("Sky preset: " + FlamezSettings.skyName() + "  (click to cycle)");
    }

    private void addToggle(int left, int right, int y, String name,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        addRenderableWidget(toggleButton(left, y, name, getter, setter));
        addRenderableWidget(toggleButton(right, y, name + " status", getter, setter));
    }

    private Button toggleButton(int x, int y, String name,
                                java.util.function.BooleanSupplier getter,
                                java.util.function.Consumer<Boolean> setter) {
        return Button.builder(toggleLabel(name, getter.getAsBoolean()), button -> {
            boolean next = !getter.getAsBoolean();
            setter.accept(next);
            button.setMessage(toggleLabel(name, next));
        }).bounds(x, y, BUTTON_WIDTH, 20).build();
    }

    private Component toggleLabel(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = Math.max(34, (this.height - 250) / 2);
        graphics.fill(left - 12, top - 12, left + PANEL_WIDTH + 12, top + 278, 0xE8101015);
        graphics.fill(left - 12, top - 12, left + PANEL_WIDTH + 12, top - 9, 0xFFFF542E);
        graphics.drawCenteredString(this.font, "FLAMEZ CLIENT", this.width / 2, top + 5, 0xFFFF653D);
        graphics.drawCenteredString(this.font, "VISUALS MENU", this.width / 2, top + 20, 0xFFE8E8E8);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
